const app = angular.module('WeatherApp', []);

app.controller('WeatherController', ['$scope', '$http', function ($scope, $http) {
    $scope.cityName = '';
    $scope.weatherData = null;
    $scope.error = '';
    $scope.weatherIcon = 'fa-cloud';  // Default icon

    const API_KEY = '9884d182b8e459f8cc8b9b67ca993f17'; // Replace with your valid key

    $scope.getWeather = function () {
        if ($scope.cityName.trim() === '') {
            $scope.error = '⚠️ Please enter a valid city name!';
            $scope.weatherData = null;
            return;
        }

        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${$scope.cityName}&appid=${API_KEY}&units=metric`;

        $http.get(apiUrl)
            .then(function (response) {
                $scope.weatherData = response.data;
                $scope.error = '';

                // Weather condition mapping to icons
                const weatherCondition = response.data.weather[0].main.toLowerCase();
                if (weatherCondition.includes('cloud')) {
                    $scope.weatherIcon = 'fa-cloud';
                } else if (weatherCondition.includes('rain')) {
                    $scope.weatherIcon = 'fa-cloud-showers-heavy';
                } else if (weatherCondition.includes('clear')) {
                    $scope.weatherIcon = 'fa-sun';
                } else if (weatherCondition.includes('snow')) {
                    $scope.weatherIcon = 'fa-snowflake';
                } else {
                    $scope.weatherIcon = 'fa-cloud';
                }
            })
            .catch(function (error) {
                $scope.weatherData = null;
                $scope.error = '❌ City not found or API error occurred. Please try again!';
            });
    };
}]);

// Custom filter to capitalize the first letter
app.filter('capitalize', function () {
    return function (input) {
        return input ? input.charAt(0).toUpperCase() + input.slice(1) : '';
    };
});
