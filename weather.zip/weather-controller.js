app.controller('WeatherController', function ($scope, $http) {
  $scope.city = '';
  $scope.weather = null;
  $scope.error = null;
  $scope.favorites = [];

  const API_KEY = 'YOUR_API_KEY';
  const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

  $scope.getWeather = function (cityName) {
    const cityToSearch = cityName || $scope.city;
    $scope.error = null;

    $http.get(`${BASE_URL}?q=${cityToSearch}&appid=${API_KEY}&units=metric`)
      .then(function (response) {
        $scope.weather = response.data;
        if (!$scope.favorites.includes(cityToSearch)) {
          $scope.favorites.push(cityToSearch);
        }
      })
      .catch(function () {
        $scope.error = 'City not found. Please try again.';
      });
  };
});
